<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="../css/header_style.css">
	</head>
	<body>
		<div class="header">
			<h2 id="title">Portal</h2>
			<div class="menu">
				 <ul>
				  <li><a href="index.php">Home</a></li>
				  <li><a href="register.php">Register person</a></li>
				  <li><a href="listing.php">list people</a></li>
				</ul> 
			</div>
			<form action="index.php" method="POST">
				<input id="logout" type="submit" name="logout" value="log out"/>
			</form>
		</div>
	</body>
</html>