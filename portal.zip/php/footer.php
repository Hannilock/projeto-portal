<?php
	require '../css/fonts.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="../css/footer_style.css">
	</head>
	<body>
		<div class="footerholder">
			<p>Website made by Virgínia M. Carvalho</p>
		</div>
	</body>
</html>