Patch 27.07.01
O que falta:
bug no excluir de dados;

~~Virg�nia M. Carvalho, 401 INFO.