<?php
	header("Location: ./php/");
?>
